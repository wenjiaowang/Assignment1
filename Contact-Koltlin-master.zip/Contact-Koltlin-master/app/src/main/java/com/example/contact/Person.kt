package com.example.contact

class Person(val name:String, val phoneNum:String)