package com.example.contact

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.contact_detail.*
import android.Manifest

class DailyDetail: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.contact_detail)
        val name = intent.getStringExtra("name").toString()
        val number = intent.getStringExtra("number").toString()

        // 更新到显示上
        name_detail.text = name
        number_detail.text = number

        btn_detail_dialing.setOnClickListener {
//            Toast.makeText(this, "拨打电话$number", Toast.LENGTH_SHORT).show()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 1)
            } else {
                call()
            }
        }

        btn_detail_sms.setOnClickListener {
//            Toast.makeText(this, "发送短信$number", Toast.LENGTH_SHORT).show()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), 2)
            } else {
                sendSMS()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            1 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    call()
                } else {
                    Toast.makeText(this, "You denied the permission", Toast.LENGTH_SHORT).show()
                }
            }
            2 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    sendSMS()
                } else {
                    Toast.makeText(this, "You denied the permission", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun call() {
        try {
            val number = intent.getStringExtra("number").toString()
            val otherIntent = Intent(Intent.ACTION_CALL)
            otherIntent.data = Uri.parse("tel:$number")
            startActivity(otherIntent)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    private fun sendSMS() {
        val name = intent.getStringExtra("name").toString()
        val number = intent.getStringExtra("number").toString()
        val otherIntent = Intent()
        otherIntent.action = Intent.ACTION_SENDTO//发短信的action
        otherIntent.data = Uri.parse("smsto:$number")//smsto:后面的是收信人，可以随便改
        otherIntent.putExtra("sms_body", "$name, 我们晚上一起吃完饭吧?嘻嘻嘻...")//这里的第二个参数是短信内容
        startActivity(otherIntent)
    }
}