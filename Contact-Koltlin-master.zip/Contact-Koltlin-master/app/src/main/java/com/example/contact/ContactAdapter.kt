package com.example.contact

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ContactAdapter(val activity: MainActivity, val contactList: List<Person>): RecyclerView.Adapter<ContactAdapter.ViewHolder>(){
    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.name)
        val number: TextView = view.findViewById(R.id.number)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.contact_item, parent, false)
        val viewHolder = ViewHolder(view)
        viewHolder.itemView.setOnClickListener {
            val position = viewHolder.adapterPosition
            val contactItem = contactList[position]
//            Toast.makeText(parent.context, "you click view ${daily.title}",
//                Toast.LENGTH_SHORT).show()

            val name = contactItem.name
            val number = contactItem.phoneNum
            val intent = Intent(activity, DailyDetail::class.java)
            intent.putExtra("name", name)
            intent.putExtra("number", number)
            activity.startActivity(intent);
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contactItem =contactList[position]
        holder.name.text = contactItem.name
        holder.number.text = contactItem.phoneNum
    }

    override fun getItemCount(): Int = contactList.size
}